# Asisten Pribadi

Aplikasi mobile (React Native + Expo) dengan 4 fitur:
- **Chat** — tanya jawab umum via Claude API
- **Catatan** — catatan pribadi dengan pencarian
- **Tugas** — to-do list dengan reminder lokal
- **WhatsApp** — ringkasan notifikasi WhatsApp (khusus Android)

## ⚠️ Batasan penting

Fitur ringkasan notifikasi WhatsApp **hanya bisa berjalan di Android**. Apple tidak
mengizinkan aplikasi pihak ketiga membaca isi notifikasi dari aplikasi lain di iOS —
ini kebijakan platform, bukan keterbatasan kode. Jika Anda pakai iPhone, tab WhatsApp
akan menampilkan pesan penjelasan, dan Anda perlu alternatif manual (misalnya forward
chat penting ke aplikasi ini, atau screenshot lalu tempel ke tab Chat untuk diringkas).

## Setup awal

```bash
npm install
```

1. Buka aplikasi, masuk ke tab **Pengaturan**, masukkan Anthropic API key Anda
   (dari https://console.anthropic.com). Key hanya disimpan lokal di perangkat.

2. Jalankan mode pengembangan biasa (fitur Chat, Catatan, Tugas sudah bisa dites):
   ```bash
   npx expo start
   ```
   Scan QR code dengan aplikasi Expo Go di HP Anda.

## Setup fitur WhatsApp (Android, wajib custom build)

Modul pembaca notifikasi (`react-native-android-notification-listener`) memakai kode
native Android, jadi **tidak bisa jalan lewat Expo Go** — harus di-build sebagai APK
sendiri (dev client / bare workflow):

```bash
npx expo prebuild
npx expo run:android
```

Setelah aplikasi ter-install, buka tab **WhatsApp** di app, lalu ikuti tombol
"Buka Pengaturan Izin" untuk memberi izin *Notification Access* ke aplikasi ini
(pengaturan Android akan terbuka otomatis). Setelah izin diberikan, notifikasi WhatsApp
yang masuk akan otomatis tersimpan, dan Anda bisa menekan "Ringkas Sekarang" untuk
membuat ringkasan lewat Claude.

## Build APK untuk instalasi permanen

```bash
npx expo prebuild
cd android
./gradlew assembleRelease
```

APK hasil build ada di `android/app/build/outputs/apk/release/`.

Untuk iOS, build lewat Xcode setelah `npx expo prebuild` (fitur WhatsApp otomatis
disembunyikan/nonaktif di iOS).

## Struktur proyek

```
App.js                          # navigasi tab utama
src/
  screens/
    ChatScreen.js                # tab chat
    NotesScreen.js                # tab catatan
    TodoScreen.js                 # tab tugas & reminder
    WhatsAppSummaryScreen.js      # tab ringkasan WA (Android only)
    SettingsScreen.js             # simpan API key
  services/
    claudeApi.js                  # panggilan ke Anthropic API
    storage.js                    # penyimpanan lokal (AsyncStorage)
    notifications.js              # reminder lokal (expo-notifications)
```

## Pengembangan lanjutan yang bisa ditambahkan

- Date/time picker untuk memilih waktu reminder spesifik (saat ini default 1 jam)
- Sinkronisasi cloud (misalnya Firebase) agar data tidak hilang saat ganti HP
- Kategori/tag untuk catatan dan tugas
- Riwayat chat tersimpan permanen (saat ini reset saat app ditutup)
