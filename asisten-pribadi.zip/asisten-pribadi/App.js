import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';

import ChatScreen from './src/screens/ChatScreen';
import NotesScreen from './src/screens/NotesScreen';
import TodoScreen from './src/screens/TodoScreen';
import WhatsAppSummaryScreen from './src/screens/WhatsAppSummaryScreen';
import SettingsScreen from './src/screens/SettingsScreen';

const Tab = createBottomTabNavigator();

const ICONS = {
  Chat: '💬',
  Catatan: '📝',
  Tugas: '✅',
  WhatsApp: '📲',
  Pengaturan: '⚙️',
};

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="dark" />
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: () => <Text style={{ fontSize: 18 }}>{ICONS[route.name]}</Text>,
          tabBarActiveTintColor: '#2563eb',
          headerTitleAlign: 'center',
        })}
      >
        <Tab.Screen name="Chat" component={ChatScreen} />
        <Tab.Screen name="Catatan" component={NotesScreen} />
        <Tab.Screen name="Tugas" component={TodoScreen} />
        <Tab.Screen name="WhatsApp" component={WhatsAppSummaryScreen} options={{ title: 'Ringkasan WA' }} />
        <Tab.Screen name="Pengaturan" component={SettingsScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
