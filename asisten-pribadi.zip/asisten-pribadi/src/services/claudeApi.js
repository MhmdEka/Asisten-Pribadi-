import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = 'https://api.anthropic.com/v1/messages';
const MODEL = 'claude-sonnet-5';

/**
 * Ambil API key yang disimpan user di Settings.
 * User WAJIB mengisi API key mereka sendiri dari console.anthropic.com
 */
export async function getApiKey() {
  return AsyncStorage.getItem('anthropic_api_key');
}

export async function setApiKey(key) {
  return AsyncStorage.setItem('anthropic_api_key', key);
}

/**
 * Kirim pesan chat biasa ke Claude.
 * history: [{ role: 'user'|'assistant', content: string }]
 */
export async function sendChatMessage(history, systemPrompt = '') {
  const apiKey = await getApiKey();
  if (!apiKey) {
    throw new Error('API key belum diatur. Buka Settings untuk memasukkan API key Anthropic Anda.');
  }

  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1024,
      system: systemPrompt || undefined,
      messages: history,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Claude API error (${response.status}): ${errText}`);
  }

  const data = await response.json();
  const textBlock = data.content?.find((c) => c.type === 'text');
  return textBlock ? textBlock.text : '';
}

/**
 * Ringkas kumpulan teks notifikasi WhatsApp menjadi ringkasan singkat.
 */
export async function summarizeNotifications(notificationTexts) {
  const joined = notificationTexts
    .map((n) => `[${n.sender}] ${n.text}`)
    .join('\n');

  const systemPrompt =
    'Kamu adalah asisten yang meringkas notifikasi WhatsApp menjadi poin-poin singkat dan jelas dalam Bahasa Indonesia. ' +
    'Kelompokkan berdasarkan pengirim. Tandai pesan yang tampak penting/mendesak. Jangan menambahkan opini.';

  return sendChatMessage(
    [{ role: 'user', content: `Ringkas notifikasi berikut:\n\n${joined}` }],
    systemPrompt
  );
}
