import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export async function requestNotificationPermission() {
  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

/**
 * Jadwalkan reminder lokal untuk sebuah todo pada waktu tertentu.
 * dueDate: objek Date
 */
export async function scheduleTodoReminder(todo, dueDate) {
  if (!dueDate) return null;
  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title: 'Pengingat Tugas',
      body: todo.title,
      data: { todoId: todo.id },
    },
    trigger: dueDate,
  });
  return id;
}

export async function cancelReminder(notificationId) {
  if (!notificationId) return;
  await Notifications.cancelScheduledNotificationAsync(notificationId);
}
