import AsyncStorage from '@react-native-async-storage/async-storage';

const KEYS = {
  NOTES: 'notes',
  TODOS: 'todos',
  WA_NOTIFICATIONS: 'wa_notifications',
  WA_SUMMARIES: 'wa_summaries',
};

async function getList(key) {
  const raw = await AsyncStorage.getItem(key);
  return raw ? JSON.parse(raw) : [];
}

async function setList(key, list) {
  await AsyncStorage.setItem(key, JSON.stringify(list));
}

// ---------- Notes ----------
export async function getNotes() {
  return getList(KEYS.NOTES);
}

export async function addNote(note) {
  const notes = await getNotes();
  const newNote = { id: Date.now().toString(), createdAt: new Date().toISOString(), ...note };
  notes.unshift(newNote);
  await setList(KEYS.NOTES, notes);
  return newNote;
}

export async function deleteNote(id) {
  const notes = await getNotes();
  await setList(KEYS.NOTES, notes.filter((n) => n.id !== id));
}

export async function searchNotes(query) {
  const notes = await getNotes();
  const q = query.trim().toLowerCase();
  if (!q) return notes;
  return notes.filter(
    (n) =>
      n.title?.toLowerCase().includes(q) ||
      n.content?.toLowerCase().includes(q)
  );
}

// ---------- Todos / Reminders ----------
export async function getTodos() {
  return getList(KEYS.TODOS);
}

export async function addTodo(todo) {
  const todos = await getTodos();
  const newTodo = {
    id: Date.now().toString(),
    done: false,
    createdAt: new Date().toISOString(),
    ...todo,
  };
  todos.unshift(newTodo);
  await setList(KEYS.TODOS, todos);
  return newTodo;
}

export async function toggleTodo(id) {
  const todos = await getTodos();
  const updated = todos.map((t) => (t.id === id ? { ...t, done: !t.done } : t));
  await setList(KEYS.TODOS, updated);
  return updated;
}

export async function deleteTodo(id) {
  const todos = await getTodos();
  await setList(KEYS.TODOS, todos.filter((t) => t.id !== id));
}

// ---------- WhatsApp notifications (raw + ringkasan) ----------
export async function saveIncomingNotification(notif) {
  const list = await getList(KEYS.WA_NOTIFICATIONS);
  list.unshift({ id: Date.now().toString(), receivedAt: new Date().toISOString(), ...notif });
  // Simpan maksimal 200 notifikasi terakhir biar storage tidak membengkak
  await setList(KEYS.WA_NOTIFICATIONS, list.slice(0, 200));
}

export async function getUnprocessedNotifications() {
  return getList(KEYS.WA_NOTIFICATIONS);
}

export async function clearNotifications() {
  await setList(KEYS.WA_NOTIFICATIONS, []);
}

export async function saveSummary(summaryText) {
  const summaries = await getList(KEYS.WA_SUMMARIES);
  summaries.unshift({ id: Date.now().toString(), createdAt: new Date().toISOString(), text: summaryText });
  await setList(KEYS.WA_SUMMARIES, summaries.slice(0, 50));
}

export async function getSummaries() {
  return getList(KEYS.WA_SUMMARIES);
}
