import React, { useCallback, useEffect, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Platform,
  Linking,
  ActivityIndicator,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import {
  getUnprocessedNotifications,
  saveIncomingNotification,
  clearNotifications,
  saveSummary,
  getSummaries,
} from '../services/storage';
import { summarizeNotifications } from '../services/claudeApi';

// Library ini butuh custom dev build (bukan Expo Go) karena memakai native module.
// Lihat README untuk langkah setup lengkap (expo prebuild + izin Android).
let NotificationListener = null;
if (Platform.OS === 'android') {
  try {
    NotificationListener = require('react-native-android-notification-listener').default;
  } catch (e) {
    // Package belum ter-link, akan ditangani di UI
  }
}

export default function WhatsAppSummaryScreen() {
  const [permissionGranted, setPermissionGranted] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [summaries, setSummaries] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const checkPermission = useCallback(async () => {
    if (Platform.OS !== 'android' || !NotificationListener) return;
    const status = await NotificationListener.getPermissionStatus();
    setPermissionGranted(status === 'authorized');
  }, []);

  const loadData = useCallback(async () => {
    setNotifications(await getUnprocessedNotifications());
    setSummaries(await getSummaries());
  }, []);

  useFocusEffect(
    useCallback(() => {
      checkPermission();
      loadData();
    }, [checkPermission, loadData])
  );

  // Listener untuk notifikasi WhatsApp yang masuk secara real-time.
  useEffect(() => {
    if (Platform.OS !== 'android' || !NotificationListener) return undefined;

    const subscription = NotificationListener.onNotificationReceived(async (notification) => {
      if (notification?.app !== 'com.whatsapp') return;
      await saveIncomingNotification({
        sender: notification.title || 'Tidak diketahui',
        text: notification.text || '',
      });
      loadData();
    });

    return () => subscription?.remove?.();
  }, [loadData]);

  const openSettings = () => {
    if (NotificationListener) {
      NotificationListener.requestPermission();
    } else {
      Linking.openSettings();
    }
  };

  const handleSummarize = async () => {
    if (notifications.length === 0) return;
    setLoading(true);
    setError(null);
    try {
      const summaryText = await summarizeNotifications(notifications);
      await saveSummary(summaryText);
      await clearNotifications();
      loadData();
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  if (Platform.OS !== 'android') {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.infoText}>
          Fitur baca notifikasi WhatsApp hanya tersedia di Android. iOS tidak mengizinkan
          aplikasi pihak ketiga membaca isi notifikasi aplikasi lain.
        </Text>
      </View>
    );
  }

  if (!NotificationListener) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.infoText}>
          Modul notification listener belum terpasang. Fitur ini butuh custom dev build
          (jalankan `npx expo prebuild` lalu build APK), tidak bisa lewat Expo Go. Lihat
          README bagian "Setup Fitur WhatsApp".
        </Text>
      </View>
    );
  }

  if (!permissionGranted) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.infoText}>
          Aplikasi butuh izin akses notifikasi untuk membaca pesan WhatsApp masuk.
        </Text>
        <TouchableOpacity style={styles.permButton} onPress={openSettings}>
          <Text style={styles.permButtonText}>Buka Pengaturan Izin</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.statusBar}>
        <Text style={styles.statusText}>{notifications.length} notifikasi belum diringkas</Text>
        <TouchableOpacity
          style={[styles.summarizeButton, notifications.length === 0 && styles.disabledButton]}
          onPress={handleSummarize}
          disabled={notifications.length === 0 || loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.summarizeText}>Ringkas Sekarang</Text>
          )}
        </TouchableOpacity>
      </View>
      {error ? <Text style={styles.error}>{error}</Text> : null}

      <FlatList
        data={summaries}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 12 }}
        ListEmptyComponent={
          <Text style={styles.emptyText}>Belum ada ringkasan. Tekan "Ringkas Sekarang".</Text>
        }
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.cardDate}>{new Date(item.createdAt).toLocaleString('id-ID')}</Text>
            <Text style={styles.cardContent}>{item.text}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  centerContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  infoText: { textAlign: 'center', color: '#374151', marginBottom: 16, lineHeight: 20 },
  permButton: { backgroundColor: '#2563eb', paddingHorizontal: 20, paddingVertical: 10, borderRadius: 10 },
  permButtonText: { color: '#fff', fontWeight: '600' },
  statusBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  statusText: { color: '#374151' },
  summarizeButton: { backgroundColor: '#2563eb', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 },
  disabledButton: { backgroundColor: '#93c5fd' },
  summarizeText: { color: '#fff', fontWeight: '600' },
  error: { color: '#dc2626', textAlign: 'center', paddingTop: 8 },
  emptyText: { textAlign: 'center', color: '#9ca3af', marginTop: 40 },
  card: { backgroundColor: '#f8fafc', borderRadius: 10, padding: 12, marginBottom: 10 },
  cardDate: { color: '#9ca3af', fontSize: 12, marginBottom: 6 },
  cardContent: { color: '#111827', lineHeight: 20 },
});
