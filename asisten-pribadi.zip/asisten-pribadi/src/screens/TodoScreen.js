import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Switch,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getTodos, addTodo, toggleTodo, deleteTodo } from '../services/storage';
import {
  requestNotificationPermission,
  scheduleTodoReminder,
} from '../services/notifications';

export default function TodoScreen() {
  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState('');
  const [reminderOn, setReminderOn] = useState(false);

  const load = useCallback(async () => {
    setTodos(await getTodos());
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleAdd = async () => {
    if (!title.trim()) return;
    const todo = await addTodo({ title: title.trim() });

    if (reminderOn) {
      const granted = await requestNotificationPermission();
      if (granted) {
        // Default: ingatkan 1 jam dari sekarang. Sesuaikan sesuai kebutuhan Anda,
        // atau tambahkan date/time picker untuk memilih waktu spesifik.
        const dueDate = new Date(Date.now() + 60 * 60 * 1000);
        await scheduleTodoReminder(todo, dueDate);
      }
    }

    setTitle('');
    load();
  };

  const handleToggle = async (id) => {
    await toggleTodo(id);
    load();
  };

  const handleDelete = async (id) => {
    await deleteTodo(id);
    load();
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={todos}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 12 }}
        ListEmptyComponent={<Text style={styles.emptyText}>Belum ada tugas.</Text>}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <TouchableOpacity onPress={() => handleToggle(item.id)} style={styles.checkbox}>
              <Text>{item.done ? '✅' : '⬜'}</Text>
            </TouchableOpacity>
            <Text style={[styles.rowText, item.done && styles.doneText]}>{item.title}</Text>
            <TouchableOpacity onPress={() => handleDelete(item.id)}>
              <Text style={styles.deleteText}>Hapus</Text>
            </TouchableOpacity>
          </View>
        )}
      />
      <View style={styles.inputArea}>
        <View style={styles.reminderRow}>
          <Text>Ingatkan saya (1 jam lagi)</Text>
          <Switch value={reminderOn} onValueChange={setReminderOn} />
        </View>
        <View style={styles.inputRow}>
          <TextInput
            style={styles.input}
            placeholder="Tugas baru..."
            value={title}
            onChangeText={setTitle}
            onSubmitEditing={handleAdd}
          />
          <TouchableOpacity style={styles.addButton} onPress={handleAdd}>
            <Text style={styles.addText}>Tambah</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  emptyText: { textAlign: 'center', color: '#9ca3af', marginTop: 40 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  checkbox: { marginRight: 10 },
  rowText: { flex: 1, fontSize: 15 },
  doneText: { textDecorationLine: 'line-through', color: '#9ca3af' },
  deleteText: { color: '#dc2626' },
  inputArea: { padding: 12, borderTopWidth: 1, borderTopColor: '#e5e7eb' },
  reminderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  inputRow: { flexDirection: 'row' },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#d1d5db',
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  addButton: {
    marginLeft: 8,
    backgroundColor: '#2563eb',
    borderRadius: 10,
    justifyContent: 'center',
    paddingHorizontal: 14,
  },
  addText: { color: '#fff', fontWeight: '600' },
});
