import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { getApiKey, setApiKey } from '../services/claudeApi';

export default function SettingsScreen() {
  const [key, setKey] = useState('');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    getApiKey().then((k) => setKey(k || ''));
  }, []);

  const handleSave = async () => {
    await setApiKey(key.trim());
    setSaved(true);
    Alert.alert('Tersimpan', 'API key berhasil disimpan di perangkat Anda.');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Anthropic API Key</Text>
      <Text style={styles.helper}>
        Dapatkan API key Anda di console.anthropic.com. Key disimpan lokal di perangkat, tidak
        dikirim ke server manapun selain langsung ke Anthropic.
      </Text>
      <TextInput
        style={styles.input}
        value={key}
        onChangeText={(t) => {
          setKey(t);
          setSaved(false);
        }}
        placeholder="sk-ant-..."
        secureTextEntry
        autoCapitalize="none"
      />
      <TouchableOpacity style={styles.button} onPress={handleSave}>
        <Text style={styles.buttonText}>Simpan</Text>
      </TouchableOpacity>
      {saved ? <Text style={styles.savedText}>Tersimpan ✓</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 20 },
  label: { fontSize: 16, fontWeight: '700', marginBottom: 6 },
  helper: { color: '#6b7280', marginBottom: 16, lineHeight: 18 },
  input: {
    borderWidth: 1,
    borderColor: '#d1d5db',
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 12,
  },
  button: { backgroundColor: '#2563eb', borderRadius: 10, paddingVertical: 12, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '700' },
  savedText: { color: '#16a34a', marginTop: 10, textAlign: 'center' },
});
